package Runner_Artifact;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
@RunWith(Cucumber.class)
@CucumberOptions(
features="src/test/resource/com.feature",
glue="com.stepDefination_Booking_Featured_Flight"
		)
public class Runner {
	
}


